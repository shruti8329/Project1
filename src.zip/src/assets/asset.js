import logo from "./logoGM.png";

export const assets = {
  logo,
};
