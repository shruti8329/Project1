import React, { useState, useEffect } from "react";
import { FaSearch } from "react-icons/fa";
import axios from "axios";
import "./Category.css";

const Category = ({ addItemToBilling }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [categories, setCategories] = useState([]);
  const [items, setItems] = useState([]);

  useEffect(() => {
    // Fetch categories from the API
    axios.get("http://localhost:8080/GoMart/category")
      .then((response) => {
        // Log the response to check the data structure
        console.log("Categories fetched:", response.data);
        setCategories(response.data);
      })
      .catch((error) => {
        console.error("Error fetching categories:", error);
      });
  }, []);

  useEffect(() => {
    // Fetch products based on selected category
    const categoryQuery = selectedCategory ? `?categoryid=${selectedCategory}` : "";
    axios.get(`http://localhost:8080/GoMart/product${categoryQuery}`)
      .then((response) => {
        // Log the response to check the data structure
        console.log("Products fetched:", response.data);
        setItems(response.data);
      })
      .catch((error) => {
        console.error("Error fetching items:", error);
      });
  }, [selectedCategory]);

  const filteredItems = items.filter((item) =>
    item.productname.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="category-container">
      <div className="category-items">
        <div className="search-category-container">
          <div className="search-bar">
            <FaSearch className="search-icon" />
            <input
              type="text"
              placeholder="Search..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="category-dropdown"
          >
            <option value="">All Categories</option>
            {categories.length > 0 ? (
              categories.map((category) => (
                <option key={category.categoryid} value={category.categoryid}>
                  {category.categoryname}
                </option>
              ))
            ) : (
              <option value="">Loading...</option>
            )}
          </select>
        </div>

        <div className="items-container">
          <div className="items-grid">
            {filteredItems.length > 0 ? (
              filteredItems.map((item) => (
                <div key={item.productid} className="item-card" onClick={() => addItemToBilling(item)}>
                  <img src={item.product_image} alt={item.productname} />
                  <div className="item-details">
                    <h5>{item.productname}</h5>
                    <h6> ₹ {item.product_price.toFixed(2)}</h6>
                  </div>
                </div> 
              ))
            ) : (
              <p>No items found.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Category;
