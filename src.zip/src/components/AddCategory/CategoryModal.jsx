import React, { useState, useEffect } from 'react';
import { Modal, Box, TextField, Button } from '@mui/material';
import axios from 'axios';
import { toast } from 'react-toastify';

const modalStyle = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};

const CategoryModal = ({ open, handleClose, editCategory, loadCategories }) => {
  const [categoryname, setCategoryname] = useState('');
  const [image, setImage] = useState(null);
  const [categoryId, setCategoryId] = useState(null);

  useEffect(() => {
    if (editCategory) {
      setCategoryname(editCategory.categoryname);
      setCategoryId(editCategory.categoryid);
    } else {
      setCategoryname('');
      setCategoryId(null);
    }
  }, [editCategory]);

  const handleImageChange = (e) => {
    setImage(e.target.files[0]);
  };

  const handleSubmit = async () => {
    const formData = new FormData();
    formData.append('categoryname', categoryname);
    formData.append('image', image);

    try {
      if (categoryId) {
        await axios.put(`http://localhost:8080/GoMart/category/updateCategory/${categoryId}`, formData);
        toast.success('Category updated successfully!');
      } else {
        await axios.post('http://localhost:8080/GoMart/category/addCategory', formData);
        toast.success('Category added successfully!');
      }
      loadCategories();
      handleClose();
    } catch (error) {
      console.error('There was an error saving the category!', error);
      toast.error('Failed to save category');
    }
  };

  return (
    <Modal
      open={open}
      onClose={handleClose}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box sx={modalStyle}>
        <h2>{categoryId ? 'Edit Category' : 'Add Category'}</h2>
        <TextField
          label="Category Name"
          value={categoryname}
          onChange={(e) => setCategoryname(e.target.value)}
          fullWidth
          margin="normal"
        />
        <input type="file" onChange={handleImageChange} />
        <Button variant="contained" color="primary" onClick={handleSubmit}>
          Save
        </Button>
      </Box>
    </Modal>
  );
};

export default CategoryModal;
