import React from "react";
import { FaTrash } from "react-icons/fa";
import PersonAddIcon from "@mui/icons-material/PersonAdd";
import "./Billing.css";

const BillingPage = ({ items, setItems }) => {
  const handleDelete = (id) => {
    const updatedItems = items.filter((item) => item.id !== id);
    setItems(updatedItems);
  };

  return (
    <div className="billing-page">
      <div className="header">
        <input type="text" placeholder="Walk-In Customer" className="form-control" />
        <button className="btn btn-success add-btn">
          <PersonAddIcon style={{ color: "white", marginRight: "5px" }} /> Add
        </button>
      </div>
      <table className="table table-striped item-table">
        <thead>
          <tr>
            <th>Sl</th>
            <th>Item</th>
            <th>Price</th>
            <th>Qty</th>
            <th>Total</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item, index) => (
            <tr key={index}>
              <td>{index + 1}</td>
              <td>{item.desc}</td>
              <td> ₹ {item.product_price}</td>
              <td>{item.qty}</td>
              <td> ₹ {item.product_price * item.qty}</td>
              <td>
                <FaTrash
                  className="delete-icon"
                  onClick={() => handleDelete(item.id)}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      
    </div>
  );
};

export default BillingPage;
