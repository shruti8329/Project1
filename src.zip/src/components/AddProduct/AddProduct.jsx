import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";
import PhotoCamera from "@mui/icons-material/PhotoCamera";
import "./AddProduct.css";

const AddProduct = ({ onAddProduct }) => {
  const [categoryName, setCategoryName] = useState("");
  const [productName, setProductName] = useState(""); // New state for product name
  const [productPrice, setProductPrice] = useState("");
  const [productImage, setProductImage] = useState(null);
  const navigate = useNavigate(); // Initialize useNavigate

  const handleCategoryChange = (event) => {
    setCategoryName(event.target.value);
  };

  const handleProductNameChange = (event) => {
    setProductName(event.target.value); // Handle changes to product name input
  };

  const handlePriceChange = (event) => {
    setProductPrice(event.target.value);
  };

  const handleImageChange = (event) => {
    setProductImage(event.target.files[0]);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const product = {
      categoryName,
      productName, // Include productName in the product object
      productPrice,
      productImage,
    };
    onAddProduct(product);
    setCategoryName("");
    setProductName(""); // Clear productName after submission
    setProductPrice("");
    setProductImage(null);
    navigate("/product-list"); // Navigate to ProductList page
  };

  return (
    <form onSubmit={handleSubmit} className="add-product-form">
      <h2>Add Product</h2>

      <TextField
        label="Product Name" // New input field for product name
        value={productName}
        onChange={handleProductNameChange}
        required
        fullWidth
      />

      <FormControl fullWidth>
        <InputLabel>Category</InputLabel>
        <Select value={categoryName} onChange={handleCategoryChange} required>
          <MenuItem value="Veggies">Veggies</MenuItem>
          <MenuItem value="Stationary">Stationary</MenuItem>
          <MenuItem value="Home Decore">Home Decor</MenuItem>
        </Select>
      </FormControl>

      <TextField
        label="Product Price"
        type="number"
        value={productPrice}
        onChange={handlePriceChange}
        required
        fullWidth
      />

      <Button variant="contained" component="label" startIcon={<PhotoCamera />}>
        Upload Image
        <input
          type="file"
          accept="image/*"
          hidden
          onChange={handleImageChange}
        />
      </Button>

      {productImage && <p>{productImage.name}</p>}

      <Button type="submit" variant="contained">
        Add Product
      </Button>
    </form>
  );
};

export default AddProduct;
