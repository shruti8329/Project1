import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
} from "@mui/material";

const ProductList = ({ products }) => {
  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Product </TableCell>
            <TableCell>Category</TableCell>
            <TableCell>Price</TableCell>
            <TableCell>Image</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {products.map((product, index) => (
            <TableRow key={index}>
              <TableCell>{product.productName}</TableCell>
              <TableCell>{product.categoryName}</TableCell>
              <TableCell>{product.productPrice}</TableCell>
              <TableCell>
                {product.productImage ? (
                  <img
                    src={URL.createObjectURL(product.productImage)}
                    alt={product.productImage.name}
                    style={{ width: 100, height: 100, objectFit: "cover" }}
                  />
                ) : (
                  "No Image"
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default ProductList;
