import React, { useState } from "react";
import "./HomePage.css";
import Navbar from "../layout/Navbar";
import "bootstrap/dist/css/bootstrap.min.css";
import Category from "../Category/Category";
import BillingPage from "../Billing/Billing";

const HomePage = () => {
  const [items, setItems] = useState([
   
  ]);
  
  const addItemToBilling = (item) => {
    setItems(prevItems => {
      const existingItem = prevItems.find(i => i.id === item.id);
      if (existingItem) {
        return prevItems.map(i =>
          i.id === item.id ? { ...i, qty: i.qty + 1 } : i
        );
      } else {
        return [...prevItems, { ...item, qty: 1 }];
      }
    });
  };

  

  return (
    <>
      <div className="container-fluid p-0">
        <div className="row">
          <Navbar />
        </div>
        <div className="row">
          <div className="col-md-7 categories">
            <Category addItemToBilling={addItemToBilling} />
          </div>
          <div className="col-md-5 billing-section">
            <BillingPage items={items} setItems={setItems} />
          </div>
        </div>

        <div className="row ">
          <div className="col-md-7 footerBill">
            {/* <div className="footer-content">
              <div>Sub Total: Rp {items.reduce((acc, item) => acc + item.price * item.qty, 0).toFixed(2)}</div>
              <input type="text" placeholder="Enter Discount" className="form-control" />
              <input type="text" placeholder="Service Charge" className="form-control" value="0" />
              <div>Tax Amount (0%): Rp 0.00</div>
              <input type="text" placeholder="Paid Amount" className="form-control" value="0" />
              <select className="form-control">
                <option value="Cash">Cash</option>
                <option value="Card">Card</option>
                <option value="Online">Online</option>
              </select>
            </div> */}
          </div>


          <div className="col-md-5">
           <div className="footer">
        <div className="total">
          Bill Total Rp{" "}
          {items.reduce((acc, item) => acc + item.price * item.qty, 0).toFixed(2)}
        </div>
        <button className="btn btn-danger clear-btn" onClick={() => setItems([])}>
          Clear All
        </button>
        <button className="btn btn-primary order-btn">Place Order</button>
      </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default HomePage;
