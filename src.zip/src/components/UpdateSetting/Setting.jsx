import React, { useState } from "react";
import { TextField, Button, IconButton } from "@mui/material";
import PhotoCamera from "@mui/icons-material/PhotoCamera";
import { useNavigate } from "react-router-dom";
import "./Setting.css";

const Setting = ({ addSetting }) => {
  const [businessName, setBusinessName] = useState("");
  const [businessMobile, setBusinessMobile] = useState("");
  const [businessEmail, setBusinessEmail] = useState("");
  const [businessAddress, setBusinessAddress] = useState("");
  const [businessGstNumber, setBusinessGstNumber] = useState("");
  const [businessLogo, setBusinessLogo] = useState(null);

  const navigate = useNavigate();

  const handleBusinessNameChange = (event) => {
    setBusinessName(event.target.value);
  };

  const handleBusinessMobileChange = (event) => {
    setBusinessMobile(event.target.value);
  };

  const handleBusinessEmailChange = (event) => {
    setBusinessEmail(event.target.value);
  };

  const handleBusinessAddressChange = (event) => {
    setBusinessAddress(event.target.value);
  };

  const handleBusinessGstNumberChange = (event) => {
    setBusinessGstNumber(event.target.value);
  };

  const handleBusinessLogoChange = (event) => {
    setBusinessLogo(event.target.files[0]);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const businessDetails = {
      id: Date.now(),
      businessName,
      businessMobile,
      businessEmail,
      businessAddress,
      businessGstNumber,
      businessLogo,
    };
    addSetting(businessDetails);
    navigate("/setting-list");
  };

  return (
    <form onSubmit={handleSubmit} className="setting-form">
      <h2>Business Settings</h2>

      <TextField
        label="Business Name"
        value={businessName}
        onChange={handleBusinessNameChange}
        required
        fullWidth
      />

      <TextField
        label="Mobile Number"
        type="tel"
        value={businessMobile}
        onChange={handleBusinessMobileChange}
        required
        fullWidth
      />

      <TextField
        label="Email"
        type="email"
        value={businessEmail}
        onChange={handleBusinessEmailChange}
        required
        fullWidth
      />

      <TextField
        label="Address"
        value={businessAddress}
        onChange={handleBusinessAddressChange}
        required
        fullWidth
      />

      <TextField
        label="GST Number"
        value={businessGstNumber}
        onChange={handleBusinessGstNumberChange}
        required
        fullWidth
      />

      <div className="button-group">
        <Button
          variant="contained"
          component="label"
          startIcon={<PhotoCamera />}
        >
          Upload Logo
          <input
            type="file"
            accept="image/*"
            hidden
            onChange={handleBusinessLogoChange}
          />
        </Button>

        <Button type="submit" variant="contained">
          Save Settings
        </Button>
      </div>

      {businessLogo && <p>{businessLogo.name}</p>}
    </form>
  );
};

export default Setting;
